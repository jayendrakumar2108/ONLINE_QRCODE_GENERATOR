const express = require('express');
const qr = require('qr-image');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});


app.post('/generate', (req, res) => {
    const link = req.body.link;
    if (!link) {
        res.status(400).send('Link is required.');
        return;
    }

    try {
        const qr_png = qr.image(link, { type: 'png' });
        res.setHeader('Content-Type', 'image/png');
        qr_png.pipe(res);
    } catch (err) {
        console.error('Error generating QR code:', err);
        res.status(500).send('Error generating QR code.');
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
